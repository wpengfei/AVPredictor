from distutils.core import setup
setup(name="scanf",
      version="1.2",
      description="scanf-like module for Python",
      author="Danny Yoo",
      author_email="dyoo@hkn.eecs.berkeley.edu",
      url="http://hkn.eecs.berkeley.edu/~dyoo/python/scanf/",
      py_modules=["scanf"])
